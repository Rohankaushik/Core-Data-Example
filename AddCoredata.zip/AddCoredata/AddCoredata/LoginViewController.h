//
//  LoginViewController.h
//  AddCoredata
//
//  Created by Apple Sigma on 27/12/16.
//  Copyright © 2016 Apple Sigma. All rights reserved.
//

#import "ViewController.h"

@interface LoginViewController : ViewController

@property (strong, nonatomic) IBOutlet UITextField *txtEmail;

@property (strong, nonatomic) IBOutlet UITextField *txtPassword;

- (IBAction)btnLogin:(id)sender;

- (IBAction)btnNewUser:(id)sender;

@end

