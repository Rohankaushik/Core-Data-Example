//
//  ViewController.h
//  AddCoredata
//
//  Created by Apple Sigma on 27/12/16.
//  Copyright © 2016 Apple Sigma. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface ViewController : UIViewController 
{
NSFetchedResultsController *fetchedResultsController;
NSManagedObjectContext *managedObjectContext;
}

//@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;

@property (strong, nonatomic) IBOutlet UIButton *btnOutletSignUp;

@property (strong, nonatomic) IBOutlet UIImageView *imgProfilePicAdd;

@property (strong, nonatomic) IBOutlet UITextField *txtEmail;

@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtMobileNo;


@property (strong) NSManagedObject *updateMangObj;

- (IBAction)btnSignUp:(id)sender;
- (IBAction)btnTakePicture:(id)sender;

@end

