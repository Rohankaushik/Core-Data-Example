//
//  ViewController.m
//  AddCoredata
//
//  Created by Apple Sigma on 27/12/16.
//  Copyright © 2016 Apple Sigma. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"

@interface ViewController ()<UIImagePickerControllerDelegate, UINavigationControllerDelegate>
//@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@end

@implementation ViewController
{
    UIImage *chosenImage;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    chosenImage = [UIImage imageNamed:@"placeholder.png"];
    self.navigationItem.title = @"Sign Up Page";

    self.imgProfilePicAdd.layer.cornerRadius = self.imgProfilePicAdd.frame.size.width / 2;
    self.imgProfilePicAdd.clipsToBounds = YES;
    
    [self.btnOutletSignUp setTitle: @"Sign Up" forState: UIControlStateNormal];
    
    //------------------------UPDATE DATA HERE----------------------//
    if (self.updateMangObj)
    {
        self.navigationItem.title = @"Update Page";
        [self.btnOutletSignUp setTitle: @"Update" forState: UIControlStateNormal];
        
        [self.txtEmail setText:[self.updateMangObj valueForKey:@"email"]];
        [self.txtPassword setText:[self.updateMangObj valueForKey:@"password"]];
        [self.txtMobileNo setText:[self.updateMangObj valueForKey:@"mobile"]];
        
        NSData *data = [self.updateMangObj valueForKey:@"image"];
        UIImage *image = [UIImage imageWithData:data];
        [self.imgProfilePicAdd setImage:image];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}

-(void)viewWillAppear:(BOOL)animated
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    

}

-(void)viewDidAppear:(BOOL)animated
{
//    self.txtEmail.text = @"";
//    self.txtMobileNo.text = @"";
//    self.txtPassword.text = @"";
}

//-------------------- Get NSManagedObjectContext Object ------------------------------//

- (NSManagedObjectContext *)managedObjectContext
{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)])
    {
        context = [delegate managedObjectContext];
    }
    return context;
}
//---------------------------------------------------------------------------------------//

- (IBAction)btnSignUp:(id)sender
{
    if ([_txtEmail.text isEqual:@""])
    {
        [self.txtEmail setValue:[UIColor redColor]
                        forKeyPath:@"_placeholderLabel.textColor"];
        return;
    }
    if ([_txtPassword.text isEqual:@""])
    {
        [self.txtPassword setValue:[UIColor redColor]
                     forKeyPath:@"_placeholderLabel.textColor"];
        return;
    }
    if ([_txtMobileNo.text isEqual:@""])
    {
        [self.txtMobileNo setValue:[UIColor redColor]
                        forKeyPath:@"_placeholderLabel.textColor"];

        return;
    }
//---------------------------- Set the DATA in Core DATA -----------------------------------//
    NSManagedObjectContext *context = [self managedObjectContext];
    NSManagedObject *newDevice;
    //------------------------UPDATE DATA HERE----------------------//
    if (self.updateMangObj)
    {
        [self.updateMangObj setValue:self.txtEmail.text forKey:@"email"];
        [self.updateMangObj setValue:self.txtPassword.text forKey:@"password"];
        [self.updateMangObj setValue:self.txtMobileNo.text forKey:@"mobile"];

        
        NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(chosenImage)];
        [self.updateMangObj setValue:imageData forKey:@"image"];
    }
    else
    {
    // Create a new managed object
        newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"PersonalInformation" inManagedObjectContext:context];
        [newDevice setValue:self.txtEmail.text forKey:@"email"];
        [newDevice setValue:self.txtPassword.text forKey:@"password"];
        [newDevice setValue:self.txtMobileNo.text forKey:@"mobile"];
    
        //---------------------------- Set image into Core Data -----------------------------//
        
        NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(chosenImage)];
        [newDevice setValue:imageData forKey:@"image"];
        //------------------------------------------------------------------------------------//
    }

    NSError *error = nil;
    // Save the object to persistent store
    if (![context save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if (newDevice != nil || self.updateMangObj != nil)
    {
        HomeViewController *homeVC = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:homeVC animated:YES];
    }
}

//--------------------ADD YOUR PROFILE PICHTURE (UIImagePickerController)------------------------------//

- (IBAction)btnTakePicture:(id)sender
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];

}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    chosenImage = info[UIImagePickerControllerEditedImage];
    self.imgProfilePicAdd.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////

@end
