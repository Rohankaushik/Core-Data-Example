//
//  HomeViewController.h
//  AddCoredata
//
//  Created by Apple Sigma on 27/12/16.
//  Copyright © 2016 Apple Sigma. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface HomeViewController : ViewController<UITableViewDataSource, UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tblView;
- (IBAction)btnLogout:(id)sender;


@end
