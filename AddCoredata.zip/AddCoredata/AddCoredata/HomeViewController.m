//
//  HomeViewController.m
//  AddCoredata
//
//  Created by Apple Sigma on 27/12/16.
//  Copyright © 2016 Apple Sigma. All rights reserved.
//

#import "HomeViewController.h"
#import "PersonalDataTableViewCell.h"
#import "LoginViewController.h"

@interface HomeViewController ()
@property (strong) NSMutableArray *arrPersonalInfo;

@end

@implementation HomeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.title = @"Home Page";
}

-(void)viewWillAppear:(BOOL)animated
{
    //------------- Hide Navigation Bar-----------------//
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   }

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
//------------------------- Fetch the devices from persistent data store ------------------//

    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"PersonalInformation"];
    self.arrPersonalInfo = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    [self.tblView reloadData];
}
//---------------------------------------------------------------------------------------//


//---------------------- Get NSManagedObjectContext Object ------------------------------//
- (NSManagedObjectContext *)managedObjectContext
{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}
//---------------------------------------------------------------------------------------//

#pragma mark UITABLEVIEW DATASOURCE OR DELEGATES

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrPersonalInfo.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"cell";
    PersonalDataTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    NSManagedObject *mangObj = [self.arrPersonalInfo objectAtIndex:indexPath.row];
    [cell.lblEmail setText:[mangObj valueForKey:@"email"]];
    [cell.lblPassword setText:[mangObj valueForKey:@"password"]];
    [cell.lblMobile setText:[mangObj valueForKey:@"mobile"]];
    
    cell.imgProfile.layer.cornerRadius = cell.imgProfile.frame.size.width / 2;
    cell.imgProfile.clipsToBounds = YES;

//---------------------------- Get image from Core Data -----------------------------//
    NSData *data = [mangObj valueForKey:@"image"];
    UIImage *image = [UIImage imageWithData:data];
    [cell.imgProfile setImage:image];
//-----------------------------------------------------------------------------------//
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSManagedObject *selectedDevice = [self.arrPersonalInfo objectAtIndex:[[self.tblView indexPathForSelectedRow] row]];
    ViewController *destViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    destViewController.updateMangObj = selectedDevice;
    [self.navigationController pushViewController:destViewController animated:YES];

}

//------------ Can edit or delete the row from Core Data as well as in UITable view ----------------//

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete object from database
        [context deleteObject:[self.arrPersonalInfo objectAtIndex:indexPath.row]];
        
        NSError *error = nil;
        if (![context save:&error]) {
            NSLog(@"Can't Delete! %@ %@", error, [error localizedDescription]);
            return;
        }
        
        // Remove device from table view
        [self.arrPersonalInfo removeObjectAtIndex:indexPath.row];
        [self.tblView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}
//---------------------------------------------------------------------------------------------------//

- (IBAction)btnLogout:(id)sender
{
    LoginViewController *loginVC = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self.navigationController pushViewController:loginVC animated:YES];
}
@end
