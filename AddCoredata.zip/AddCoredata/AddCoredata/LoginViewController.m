//
//  LoginViewController.m
//  AddCoredata
//
//  Created by Apple Sigma on 27/12/16.
//  Copyright © 2016 Apple Sigma. All rights reserved.
//

#import "LoginViewController.h"
#import "ViewController.h"
#import "HomeViewController.h"
#import <CoreData/CoreData.h>

@interface LoginViewController ()
@property (strong) NSMutableArray *arrPersonalInfo;
@end

@implementation LoginViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"Login Page";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(void)viewWillAppear:(BOOL)animated
{
        
   [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil];
    
}


//-------------------- Get NSManagedObjectContext Object ------------------------------//

- (NSManagedObjectContext *)managedObjectContext
{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}
//---------------------------------------------------------------------------------------//


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    

//------------------------- Fetch the devices from persistent data store ------------------//
    
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"PersonalInformation"];
    self.arrPersonalInfo = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
   // NSLog(@"data ====== %@",self.arrPersonalInfo);
    //[self.tblView reloadData];
}
//---------------------------------------------------------------------------------------//


- (IBAction)btnLogin:(id)sender
{
    
    for (int i=0; i<_arrPersonalInfo.count; i++)
    {
        
        NSString *email = [[_arrPersonalInfo objectAtIndex:i]valueForKey:@"email"];
        NSString *pass =  [[_arrPersonalInfo objectAtIndex:i]valueForKey:@"password"];
        if ([self.txtEmail.text isEqual:email] && [self.txtPassword.text isEqual:pass])
        {
            HomeViewController *homeVC = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
            [self.navigationController pushViewController:homeVC animated:YES];
            
            return;
            
        }
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Attention !" message:@"Invalide Email_id or Password." preferredStyle:UIAlertControllerStyleAlert];
    
                UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil];
    
                [alert addAction:okAction];
                [self presentViewController:alert animated:YES completion:nil];
                return;

    
}

- (IBAction)btnNewUser:(id)sender
{
    ViewController *signUpVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self.navigationController pushViewController:signUpVC animated:YES];
}
@end
